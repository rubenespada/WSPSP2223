import java.io.Serializable;

public class Respuestas implements Serializable {
	String respuesta;

	public Respuestas(String respuesta) {
		super();
		this.respuesta = respuesta;
	}

	public String getRespuesta() {
		return respuesta;
	}

	public void setRespuesta(String respuesta) {
		this.respuesta = respuesta;
	}

}
