import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormularioCodeComponent } from './formulario-code.component';

describe('FormularioCodeComponent', () => {
  let component: FormularioCodeComponent;
  let fixture: ComponentFixture<FormularioCodeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FormularioCodeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormularioCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
