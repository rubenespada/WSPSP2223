import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Code } from 'src/app/core/model/code.model';
import { DataCodeService } from 'src/app/core/service/data-code.service';

@Component({
  selector: 'app-formulario-code',
  templateUrl: './formulario-code.component.html',
  styleUrls: ['./formulario-code.component.css']
})
export class FormularioCodeComponent {

titulo:string = "Formulario Códigos"

  idProject: number = this.route.snapshot.params['idProject'];

  cuadroPackage:string;

  cuadroFile:string;

  constructor(private codeService:DataCodeService, private route:ActivatedRoute, private router:Router){

  }

enviarCode(){
  let code = new Code(this.cuadroPackage,this.cuadroFile);
  console.log(this.idProject);
  this.codeService.addCode(code,this.idProject).subscribe(
    (response) =>{
      console.log("Se ha añadido el codigo correctamente: " + response);
      this.irAListaCodigo();
    },
    (error) => {
      console.log(error);
    }
  );
}

irAListaCodigo(){
  this.router.navigate(['code/listado/' + this.idProject]);
}

}
