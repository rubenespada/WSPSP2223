import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormularioProjectComponent } from './formulario-project.component';

describe('FormularioProjectComponent', () => {
  let component: FormularioProjectComponent;
  let fixture: ComponentFixture<FormularioProjectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FormularioProjectComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormularioProjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
