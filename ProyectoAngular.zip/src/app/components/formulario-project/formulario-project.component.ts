import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Project } from 'src/app/core/model/project.model';
import { ProjectService } from 'src/app/core/service/project.service';

@Component({
  selector: 'app-formulario-project',
  templateUrl: './formulario-project.component.html',
  styleUrls: ['./formulario-project.component.css']
})
export class FormularioProjectComponent implements OnInit{


project:any;

id:number;

titulo:String="Formulario Proyectos"

cuadroDescription:string = "";

cuadroLanguage:string = "";

cuadroOpen:boolean = false;

constructor(private projectService:ProjectService,private router:Router, private route:ActivatedRoute){

}
  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    if(this.id){
    this.projectService.obtenerPorId(this.id).subscribe(
      (response) => {
        this.project = response;
        this.cuadroDescription = this.project.description;
        this.cuadroLanguage = this.project.language;
        this.cuadroOpen = this.project.open;
      },
      (error) => {
        console.log(error);
        this.irAListaProject();
      }
    );
    }

  }

EnviarProject(){

if(!this.id){

  let project = new Project(this.cuadroDescription,this.cuadroLanguage,this.cuadroOpen);

  this.projectService.agregarProject(project).subscribe(
    (response) =>{ 
      console.log("Se ha guardado el proyecto" + response);
      this.irAListaProject();
   },
   (error) => {
    console.log("Error: " + error);
   }

  );
}else{
  this.project.description = this.cuadroDescription;
  this.project.language = this.cuadroLanguage;
  this.project.open = this.cuadroOpen;
  console.log(this.project);
  this.projectService.actualizarProject(this.id,this.project).subscribe(
    (response) =>{
      console.log("Se ha actualizado el proyecto" + response);
      this.irAListaProject();
    },
    (error) =>{
      console.log("Error: " + error);
    }
  )
}

}

irAListaProject(){
  this.router.navigate(['/project/listado']);
}

}
