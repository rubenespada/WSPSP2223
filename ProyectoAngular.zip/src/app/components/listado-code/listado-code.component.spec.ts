import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListadoCodeComponent } from './listado-code.component';

describe('ListadoCodeComponent', () => {
  let component: ListadoCodeComponent;
  let fixture: ComponentFixture<ListadoCodeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListadoCodeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListadoCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
