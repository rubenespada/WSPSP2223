import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Code } from 'src/app/core/model/code.model';
import { DataCodeService } from 'src/app/core/service/data-code.service';

@Component({
  selector: 'app-listado-code',
  templateUrl: './listado-code.component.html',
  styleUrls: ['./listado-code.component.css']
})
export class ListadoCodeComponent implements OnInit {

idProject:number;

codes: any;


constructor(private dataCodeService:DataCodeService,private route:ActivatedRoute, private router:Router){

}

  ngOnInit(): void {
    this.idProject = this.route.snapshot.params['idProject'];
    this.dataCodeService.cargarCodes(this.idProject).subscribe(
      (response) =>{
        console.log(response);
        this.codes = response;
      },
      (error) => {
        console.log(error);
      }
    )
  }

  irAFormularioCode(){
    this.router.navigate(['code/formulario/' + this.idProject])
  }

  eliminarCode(id:number,index:number){
    this.dataCodeService.deleteCode(id).subscribe(
      (response) => {
        console.log( + response);
      },
      (error) =>{
        console.log("Se ha eliminado el proyecto con éxito" + error);
        this.codes.splice(index,1);
  
      }
    )
  }


}
