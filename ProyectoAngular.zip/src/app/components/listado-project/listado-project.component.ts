import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Project } from 'src/app/core/model/project.model';
import { ProjectService } from 'src/app/core/service/project.service';

@Component({
  selector: 'app-listado-project',
  templateUrl: './listado-project.component.html',
  styleUrls: ['./listado-project.component.css']
})
export class ListadoProjectComponent implements OnInit{

  projects: Project[] = [];

  constructor(private projectService:ProjectService, private router:Router){
    
  }
  ngOnInit(): void {
    //this.projects = this.projectService.projects;
    this.projectService.obtenerProjects().subscribe(misProjects =>{
      console.log(misProjects);

      this.projects = Object.values(misProjects);

      this.projectService.setProjects(this.projects)
    });
  }

irAFormularioProject(){
  this.router.navigate(['/project/formulario']);
}

irAFormularioProjectMod(id:number){
  this.router.navigate(['/project/formulario/' + id]);
}

eliminarProject(id:number,index:number){
  this.projectService.borrarProject(id).subscribe(
    (response) => {
      console.log( + response);
    },
    (error) =>{
      console.log("Se ha eliminado el proyecto con éxito" + error);
      this.projects.splice(index,1);

    }
  )
}

irAListadoCodigos(id:number){
  this.router.navigate(['/code/listado/' + id]);
}

}
