import { Project } from "./project.model";

export class Code{
    id:number;
    packageCode:string;
    file:string;
    project:Project;

    constructor(packageCode:string,file:string){
        this.packageCode = packageCode;
        this.file = file;
       
    }
}