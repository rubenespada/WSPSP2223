export class Project{
    id:number;
    description:string = "";
    language:string = "";
    open:boolean = false;

    constructor(description:string, languge:string, open:boolean){
        this.description = description;
        this.language = languge;
        this.open = open;
    }

}