import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Code } from '../model/code.model';

@Injectable({
  providedIn: 'root'
})
export class DataCodeService {

  API_URL = "http://localhost:8080/codes"

  constructor(private httpClient: HttpClient) { }

  cargarCodes(idProject:number) {
    return this.httpClient.get(this.API_URL + "/project/" + idProject);
  }

  addCode(code: Code, idProject:number) {
    let token = localStorage.getItem('Token');
    return this.httpClient.post(this.API_URL + "/project/" + idProject, code,{headers:{Authorization:token!}});

  }
  
  deleteCode(id:number){
    let token = localStorage.getItem('Token');
    return this.httpClient.delete(this.API_URL + '/' + id,{headers:{Authorization:token!}});
  }
}
