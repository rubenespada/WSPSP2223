import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Project } from '../model/project.model';

@Injectable({
  providedIn: 'root'
})
export class DataProjectService {

  API_URL = "http://localhost:8080/projects"

  constructor(private httpClient: HttpClient) { }

  cargarProjects() {
    return this.httpClient.get(this.API_URL);
  }

  findById(id:number){
    return this.httpClient.get(this.API_URL + "/" + id);
  }

  addProject(project: Project) {
    let token = localStorage.getItem('Token');
    return this.httpClient.post(this.API_URL, project,{headers:{Authorization:token!}});

  }

  updateProject(id:number, project:Project){
    let token = localStorage.getItem('Token');
    return this.httpClient.put(this.API_URL + '/' + id, project,{headers:{Authorization:token!}});
  }
  
  deleteProject(id:number){
    let token = localStorage.getItem('Token');
    return this.httpClient.delete(this.API_URL + '/' + id,{headers:{Authorization:token!}});
  }
}
