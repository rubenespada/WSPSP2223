import { Injectable } from '@angular/core';
import { Project } from '../model/project.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DataProjectService } from './data-project.service';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

 projects:Project[] = [];

  constructor(private dataService:DataProjectService) { }


  obtenerProjects(){
    return this.dataService.cargarProjects();
  }

  obtenerPorId(id:number){
    return this.dataService.findById(id);
  }

  setProjects(misProjects:Project[]){
    this.projects = misProjects;
  }

  agregarProject(project:Project){
   return this.dataService.addProject(project);
  }

  actualizarProject(id:number,project:Project){
    return this.dataService.updateProject(id,project);
  }

  borrarProject(id:number){
    return this.dataService.deleteProject(id);
  }



}
