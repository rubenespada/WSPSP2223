import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { ListadoProjectComponent } from 'src/app/components/listado-project/listado-project.component';
import { ListadoCodeComponent } from 'src/app/components/listado-code/listado-code.component';
import { FormularioProjectComponent } from 'src/app/components/formulario-project/formulario-project.component';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { FormularioCodeComponent } from 'src/app/components/formulario-code/formulario-code.component';

const routes: Routes = [
  {path:'',component:DashboardComponent,canActivate:[AuthGuard],children:[
    {path:'project/listado',component:ListadoProjectComponent},
    {path:'project/formulario',component:FormularioProjectComponent},
    {path:'project/formulario/:id',component:FormularioProjectComponent},
    {path:'code/listado/:idProject',component:ListadoCodeComponent},
    {path:'code/formulario/:idProject',component:FormularioCodeComponent}
  ]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
