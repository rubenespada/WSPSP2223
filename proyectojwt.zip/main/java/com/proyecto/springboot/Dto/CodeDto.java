package com.proyecto.springboot.Dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CodeDto {
	
	private Integer id;
	private String packageCode;
	private String file;
	@JsonIgnoreProperties(value="codes")
	private ProjectDto project;

}
