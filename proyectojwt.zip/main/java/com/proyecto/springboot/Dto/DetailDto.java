package com.proyecto.springboot.Dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DetailDto {
	
	private Integer id;
	private LocalDate date;
	private String content;
	private String type;
	private Float budget;
	
//	@JsonIgnoreProperties(value = "detail")
//	private ProjectDto project;

}
