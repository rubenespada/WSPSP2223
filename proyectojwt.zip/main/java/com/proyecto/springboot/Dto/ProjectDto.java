package com.proyecto.springboot.Dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectDto {
	
	private Integer id;
	private String description;
	private String language;
	private boolean open;
	
	@JsonIgnoreProperties(value = {"project"})
	private List<CodeDto> codes;
	
	//@JsonIgnoreProperties(value = {"project"})
	//private DetailDto detail;

}
