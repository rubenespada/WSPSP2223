package com.proyecto.springboot.Util;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.proyecto.springboot.Dto.CodeDto;
import com.proyecto.springboot.model.CodeModel;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class CodeMapper {
	
	private final ModelMapper modelMapper;

	public CodeDto toDto(CodeModel code) {
		return modelMapper.map(code, CodeDto.class);
	}
	
	public CodeModel toModel(CodeDto code) {
		return modelMapper.map(code, CodeModel.class);
	}

}
