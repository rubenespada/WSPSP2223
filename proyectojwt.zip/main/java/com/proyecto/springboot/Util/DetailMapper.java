package com.proyecto.springboot.Util;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.proyecto.springboot.Dto.DetailDto;
import com.proyecto.springboot.model.DetailModel;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class DetailMapper {
	
	private final ModelMapper modelMapper;
	
	public DetailDto toDto(DetailModel detail) {
		return modelMapper.map(detail, DetailDto.class);
	}
	
	public DetailModel toModel(DetailDto detail) {
		return modelMapper.map(detail, DetailModel.class);
	}

}
