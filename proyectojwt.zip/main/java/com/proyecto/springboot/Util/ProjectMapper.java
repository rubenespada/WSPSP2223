package com.proyecto.springboot.Util;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.proyecto.springboot.Dto.ProjectDto;
import com.proyecto.springboot.model.ProjectModel;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class ProjectMapper {
	
	private final ModelMapper modelMapper;

	public ProjectDto toDto(ProjectModel project) {
		return modelMapper.map(project, ProjectDto.class);
	}
	
	public ProjectModel toModel(ProjectDto project) {
		return modelMapper.map(project, ProjectModel.class);
	}

}
