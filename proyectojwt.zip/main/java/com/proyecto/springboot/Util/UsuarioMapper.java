package com.proyecto.springboot.Util;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.proyecto.springboot.Dto.UsuarioRequestDto;
import com.proyecto.springboot.Dto.UsuarioResponseDto;
import com.proyecto.springboot.model.Usuario;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class UsuarioMapper{
	
	private final ModelMapper modelMapper;

	
	public Usuario toModel(UsuarioRequestDto usuario) {
		return modelMapper.map(usuario, Usuario.class);
	}
	
	public UsuarioResponseDto toDto(Usuario usuario) {
		return modelMapper.map(usuario, UsuarioResponseDto.class);
	}

}
