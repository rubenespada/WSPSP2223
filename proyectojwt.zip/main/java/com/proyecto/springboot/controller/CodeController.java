package com.proyecto.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proyecto.springboot.Dto.CodeDto;
import com.proyecto.springboot.service.CodeService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("codes")
public class CodeController {

	@Autowired
	private CodeService codeService;

	
	@ApiOperation(value = "Obtener un code por id", notes = "Mediante esta petición recuperamos el code con dicho id en la base de datos.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK. El recurso se obtiene correctamente", response = CodeDto.class),
			@ApiResponse(code = 400, message = "Bad Request. Hay un error en la peticion.", response = String.class),
			@ApiResponse(code = 401, message = "Unaouthorized. Se necesita autorización para realizar esta petición.", response = String.class),
			@ApiResponse(code = 500, message = "Error inesperado del sistema") })
	@GetMapping("/{id}")
	public ResponseEntity<?> getById(@PathVariable Integer id) {
		CodeDto result = codeService.getById(id);
		return ResponseEntity.ok(result);
	}

	@ApiOperation(value = "Obterner todos los codes", notes = "Mediante esta petición recuperamos todos los codes existentes en la base de datos.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK. El recurso se obtiene correctamente", response = CodeDto.class),
			@ApiResponse(code = 400, message = "Bad Request. Hay un error en la peticion.", response = String.class),
			@ApiResponse(code = 401, message = "Unaouthorized. Se necesita autorización para realizar esta petición.", response = String.class),
			@ApiResponse(code = 500, message = "Error inesperado del sistema") })
	@GetMapping
	public ResponseEntity<?> getAll() {
		List<CodeDto> result = codeService.getAll();
		return ResponseEntity.ok(result);
	}
	
	@GetMapping("/project/{idProject}")
	public ResponseEntity<?> getByProject(@PathVariable Integer idProject){
		List<CodeDto> result = codeService.getByProject(idProject);
		return ResponseEntity.ok(result);
	}

	@PostMapping
	public ResponseEntity<?> addCode(@RequestBody CodeDto code) {
		CodeDto result = codeService.createCode(code);
		return new ResponseEntity<>(result, HttpStatus.CREATED);
	}
	
	@PostMapping("/project/{idProject}")
	public ResponseEntity<?> addCode(@RequestBody CodeDto code,@PathVariable Integer idProject) {
		CodeDto result = codeService.createCode(code,idProject);
		return new ResponseEntity<>(result, HttpStatus.CREATED);
	}
	


	@PutMapping("/{id}")
	public ResponseEntity<?> updateCode(@RequestBody CodeDto code, @PathVariable Integer id) {
		CodeDto result = codeService.updateCode(code, id);
		return ResponseEntity.ok(result);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteCode(@PathVariable Integer id){
	codeService.deleteCodeById(id);
	return new ResponseEntity<>("Proyecto eliminado con exito", HttpStatus.OK);
	}

}
