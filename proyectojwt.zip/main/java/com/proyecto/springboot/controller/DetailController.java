package com.proyecto.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proyecto.springboot.Dto.DetailDto;
import com.proyecto.springboot.service.DetailService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
@RestController
@RequestMapping("details")
public class DetailController {

	@Autowired
	DetailService detailService;

	@ApiOperation(value = "Obtener un detail por id", notes = "Mediante esta petición recuperamos el detail con dicho id en la base de datos.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK. El recurso se obtiene correctamente", response = DetailDto.class),
			@ApiResponse(code = 400, message = "Bad Request. Hay un error en la peticion.", response = String.class),
			@ApiResponse(code = 401, message = "Unaouthorized. Se necesita autorización para realizar esta petición.", response = String.class),
			@ApiResponse(code = 500, message = "Error inesperado del sistema") })
	@GetMapping("/{id}")
	public ResponseEntity<?> getById(@PathVariable Integer id) {
		DetailDto result = detailService.getById(id);
		return ResponseEntity.ok(result);
	}
	
	@ApiOperation(value = "Obterner todos los details", notes = "Mediante esta petición recuperamos todos los details existentes en la base de datos.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK. El recurso se obtiene correctamente", response = DetailDto.class),
			@ApiResponse(code = 400, message = "Bad Request. Hay un error en la peticion.", response = String.class),
			@ApiResponse(code = 401, message = "Unaouthorized. Se necesita autorización para realizar esta petición.", response = String.class),
			@ApiResponse(code = 500, message = "Error inesperado del sistema") })
	@GetMapping
	public ResponseEntity<?> getAll(){
		List<DetailDto> result = detailService.getAll();
		return ResponseEntity.ok(result);
	}
	
	@ApiOperation(value = "Añadir un detail", notes = "Mediante esta petición se inserta un nuevo detail en la base de datos.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK. El recurso se inserta correctamente", response = DetailDto.class),
			@ApiResponse(code = 400, message = "Bad Request. Hay un error en la peticion.", response = String.class),
			@ApiResponse(code = 401, message = "Unaouthorized. Se necesita autorización para realizar esta petición.", response = String.class),
			@ApiResponse(code = 500, message = "Error inesperado del sistema") })
	
	//PARA PODER PONER EJEMPLOS
	/*@ApiParam(
			  value = "A JSON value representing a transaction. An example of the expected schema can be found down here. The fields marked with an * means that they are required.",
			  examples = @Example(value = 
			    @ExampleProperty(
			      mediaType = MediaType.APPLICATION_JSON,
			      value = "{foo: whatever, bar: whatever2}")))*/
	@PostMapping
	public ResponseEntity<?> addDetail(@RequestBody DetailDto detail){
		DetailDto result = detailService.createDetail(detail);
		return new ResponseEntity<>(result,HttpStatus.CREATED);
	}

	@ApiOperation(value = "Actualizar un detail", notes = "Mediante esta petición se actualiza un detail existente en la base de datos.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK. El recurso se inserta correctamente", response = DetailDto.class),
			@ApiResponse(code = 400, message = "Bad Request. Hay un error en la peticion.", response = String.class),
			@ApiResponse(code = 401, message = "Unaouthorized. Se necesita autorización para realizar esta petición.", response = String.class),
			@ApiResponse(code = 500, message = "Error inesperado del sistema") })
	@PutMapping("/{id}")
	public ResponseEntity<?> updateDetail(@RequestBody DetailDto detail, @PathVariable Integer id){
		DetailDto result = detailService.updateDetail(detail, id);
		return ResponseEntity.ok(result);
	}
	
	@ApiOperation(value = "Eliminar un detail", notes = "Mediante esta petición se elimina un detail existente en la base de datos.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK. El recurso se elimina correctamente", response = String.class),
			@ApiResponse(code = 400, message = "Bad Request. Hay un error en la peticion.", response = String.class),
			@ApiResponse(code = 401, message = "Unaouthorized. Se necesita autorización para realizar esta petición.", response = String.class),
			@ApiResponse(code = 500, message = "Error inesperado del sistema") })
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteDetail(@PathVariable Integer id){
		detailService.deleteDetailById(id);
		return new ResponseEntity<>("Detalle eliminado con exito", HttpStatus.OK);
	}
	
}
