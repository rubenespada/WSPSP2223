package com.proyecto.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proyecto.springboot.Dto.ProjectDto;
import com.proyecto.springboot.service.ProjectService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

//@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("projects")
public class ProjectController {
	
	@Autowired
	private ProjectService projectService;
	
	@ApiOperation(value = "Obtener un project por id", notes = "Mediante esta petición recuperamos el project con dicho id en la base de datos.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK. El recurso se obtiene correctamente", response = ProjectDto.class),
			@ApiResponse(code = 400, message = "Bad Request. Hay un error en la peticion.", response = String.class),
			@ApiResponse(code = 401, message = "Unaouthorized. Se necesita autorización para realizar esta petición.", response = String.class),
			@ApiResponse(code = 500, message = "Error inesperado del sistema") })
	@GetMapping("/{id}")
	public ResponseEntity<?> getById(@PathVariable Integer id){
		ProjectDto result = projectService.getById(id);
		return ResponseEntity.ok(result);
	}
	
	@ApiOperation(value = "Obterner todos los projects", notes = "Mediante esta petición recuperamos todos los projects existentes en la base de datos.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK. El recurso se obtiene correctamente", response = ProjectDto.class),
			@ApiResponse(code = 400, message = "Bad Request. Hay un error en la peticion.", response = String.class),
			@ApiResponse(code = 401, message = "Unaouthorized. Se necesita autorización para realizar esta petición.", response = String.class),
			@ApiResponse(code = 500, message = "Error inesperado del sistema") })
	@GetMapping
	public ResponseEntity<?> getAll(){
		List<ProjectDto> result = projectService.getAll();
		return ResponseEntity.ok(result);
	}
	
	@ApiOperation(value = "Añadir un project", notes = "Mediante esta petición se inserta un nuevo project en la base de datos.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK. El recurso se inserta correctamente", response = ProjectDto.class),
			@ApiResponse(code = 400, message = "Bad Request. Hay un error en la peticion.", response = String.class),
			@ApiResponse(code = 401, message = "Unaouthorized. Se necesita autorización para realizar esta petición.", response = String.class),
			@ApiResponse(code = 500, message = "Error inesperado del sistema") })
	@PostMapping
	public ResponseEntity<?> addProject(@RequestBody ProjectDto project){
		ProjectDto result = projectService.createProject(project);
		return new ResponseEntity<>(result,HttpStatus.CREATED);
	}
	
	
	@ApiOperation(value = "Actualizar un project", notes = "Mediante esta petición se actualiza un project existente en la base de datos.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK. El recurso se inserta correctamente", response = ProjectDto.class),
			@ApiResponse(code = 400, message = "Bad Request. Hay un error en la peticion.", response = String.class),
			@ApiResponse(code = 401, message = "Unaouthorized. Se necesita autorización para realizar esta petición.", response = String.class),
			@ApiResponse(code = 500, message = "Error inesperado del sistema") })
	@PutMapping("/{id}")
	public ResponseEntity<?> updateProject(@RequestBody ProjectDto project, @PathVariable Integer id){
		ProjectDto result = projectService.updateProject(project, id);
		return ResponseEntity.ok(result);
		
	}
	
	@ApiOperation(value = "Eliminar un project", notes = "Mediante esta petición se elimina un  project existente en la base de datos.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK. El recurso se elimina correctamente", response = String.class),
			@ApiResponse(code = 400, message = "Bad Request. Hay un error en la peticion.", response = String.class),
			@ApiResponse(code = 401, message = "Unaouthorized. Se necesita autorización para realizar esta petición.", response = String.class),
			@ApiResponse(code = 500, message = "Error inesperado del sistema") })
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteProject(@PathVariable Integer id){
		projectService.deleteProjectById(id);
		return new ResponseEntity<>("Proyecto eliminado con exito", HttpStatus.OK);
	}
}
