package com.proyecto.springboot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.proyecto.springboot.model.CodeModel;
import com.proyecto.springboot.model.ProjectModel;

@Repository
public interface CodeRepository extends JpaRepository<CodeModel,Integer>{
	
	public List<CodeModel> findByProject(ProjectModel project);

}
