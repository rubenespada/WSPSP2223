package com.proyecto.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.proyecto.springboot.model.DetailModel;

public interface DetailRepository extends JpaRepository<DetailModel, Integer>{

}
