package com.proyecto.springboot.service;

import java.util.List;

import com.proyecto.springboot.Dto.CodeDto;

public interface CodeService {

	public List<CodeDto> getAll();
	
	public List<CodeDto> getByProject(Integer id);

	public CodeDto getById(Integer id);

	public CodeDto createCode(CodeDto code);

	public CodeDto createCode(CodeDto code, Integer idProject);

	public CodeDto updateCode(CodeDto code, Integer id);

	public void deleteCodeById(Integer id);

}
