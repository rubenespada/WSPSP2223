package com.proyecto.springboot.service;

import java.util.List;

import com.proyecto.springboot.Dto.DetailDto;

public interface DetailService {
	
	public List<DetailDto> getAll();
	
	public DetailDto getById(Integer id);
	
	public DetailDto createDetail(DetailDto detail);
	
	public DetailDto updateDetail(DetailDto detail,Integer id);
	
	public void deleteDetailById(Integer id);

}
