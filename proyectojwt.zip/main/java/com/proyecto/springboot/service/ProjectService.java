package com.proyecto.springboot.service;

import java.util.List;

import com.proyecto.springboot.Dto.ProjectDto;

public interface ProjectService {
	
	public List<ProjectDto> getAll();
	
	public ProjectDto getById(Integer id);
	
	public ProjectDto createProject(ProjectDto project);
	
	public ProjectDto updateProject(ProjectDto project, Integer id);
	
	public void deleteProjectById(Integer id);

}
