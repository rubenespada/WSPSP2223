package com.proyecto.springboot.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyecto.springboot.Dto.CodeDto;
import com.proyecto.springboot.Util.CodeMapper;
import com.proyecto.springboot.Util.ProjectMapper;
import com.proyecto.springboot.excepciones.ResourceNotFoundException;
import com.proyecto.springboot.model.CodeModel;
import com.proyecto.springboot.model.ProjectModel;
import com.proyecto.springboot.repository.CodeRepository;
import com.proyecto.springboot.repository.ProjectRepository;
import com.proyecto.springboot.service.CodeService;

// TODO: Auto-generated Javadoc
/**
 * The Class CodeServiceImpl.
 */
@Service
public class CodeServiceImpl implements CodeService {

	/** The code repository. */
	@Autowired
	private CodeRepository codeRepository;

	@Autowired
	private ProjectRepository projectRepository;

	/** The mapper. */
	@Autowired
	private CodeMapper mapper;

	/** The project mapper. */
	@Autowired
	private ProjectMapper projectMapper;

	/**
	 * Gets the all.
	 *
	 * @return the all
	 */
	@Override
	public List<CodeDto> getAll() {
		return codeRepository.findAll().stream().map(mapper::toDto).collect(Collectors.toList());
	}

	/**
	 * Gets the by id.
	 *
	 * @param id the id
	 * @return the by id
	 */
	@Override
	public CodeDto getById(Integer id) {
		return mapper
				.toDto(codeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Code", "id", id)));
	}

	/**
	 * Creates the code.
	 *
	 * @param code the code
	 * @return the code dto
	 */
	@Override
	public CodeDto createCode(CodeDto code) {
		codeRepository.save(mapper.toModel(code));
		return code;
	}

	/**
	 * Update code.
	 *
	 * @param code the code
	 * @param id   the id
	 * @return the code dto
	 */
	@Override
	public CodeDto updateCode(CodeDto code, Integer id) {
		CodeModel codeModel = codeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Code", "id", id));

		codeModel.setFile(code.getFile());
		codeModel.setPackageCode(code.getPackageCode());
		// codeModel.setProject(projectMapper.toModel(code.getProject()));

		return mapper.toDto(codeRepository.save(codeModel));
	}

	/**
	 * Delete code by id.
	 *
	 * @param id the id
	 */
	@Override
	public void deleteCodeById(Integer id) {
		CodeModel code = codeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Code", "id", id));
		codeRepository.delete(code);
	}

	@Override
	public CodeDto createCode(CodeDto code, Integer idProject) {
		CodeModel codeModel = mapper.toModel(code);
		codeModel.setProject(projectRepository.findById(idProject).get());
		codeRepository.save(codeModel);
		return mapper.toDto(codeModel);
	}

	@Override
	public List<CodeDto> getByProject(Integer id) {
		ProjectModel project = projectRepository.findById(id).get();
		return codeRepository.findByProject(project).stream().map(mapper::toDto).collect(Collectors.toList());
	}

}
