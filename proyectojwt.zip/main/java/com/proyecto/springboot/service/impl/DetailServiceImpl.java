package com.proyecto.springboot.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyecto.springboot.Dto.DetailDto;
import com.proyecto.springboot.Util.DetailMapper;
import com.proyecto.springboot.excepciones.ResourceNotFoundException;
import com.proyecto.springboot.model.DetailModel;
import com.proyecto.springboot.repository.DetailRepository;
import com.proyecto.springboot.service.DetailService;

@Service
public class DetailServiceImpl implements DetailService {
	
	@Autowired
	private DetailRepository detailRepository;
	
	@Autowired
	private DetailMapper mapper;

	@Override
	public List<DetailDto> getAll() {
		return detailRepository.findAll().stream().map(mapper::toDto).collect(Collectors.toList());
	}

	@Override
	public DetailDto getById(Integer id) {
		return mapper.toDto(detailRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Detail", "id", id)));
	}

	@Override
	public DetailDto createDetail(DetailDto detail) {
		detailRepository.save(mapper.toModel(detail));
		return detail;
	}

	@Override
	public DetailDto updateDetail(DetailDto detail, Integer id) {
		DetailModel detailModel = detailRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Detail", "id", id));
		
		detailModel.setDate(detail.getDate());
		detailModel.setBudget(detail.getBudget());
		detailModel.setContent(detail.getContent());
		detailModel.setType(detail.getType());
		
		return mapper.toDto(detailRepository.save(detailModel));
	}

	@Override
	public void deleteDetailById(Integer id) {
		DetailModel detail = detailRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Detail", "id", id));
		System.out.println(detail.getContent());
		detailRepository.delete(detail);
	}

}
