package com.proyecto.springboot.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyecto.springboot.Dto.ProjectDto;
import com.proyecto.springboot.Util.DetailMapper;
import com.proyecto.springboot.Util.ProjectMapper;
import com.proyecto.springboot.excepciones.ResourceNotFoundException;
import com.proyecto.springboot.model.ProjectModel;
import com.proyecto.springboot.repository.ProjectRepository;
import com.proyecto.springboot.service.ProjectService;


@Service
public class ProjectServiceImpl implements ProjectService {
	
	@Autowired
	private ProjectRepository projectRepository;
	
	@Autowired
	private ProjectMapper mapper;
	
	@Autowired
	private DetailMapper detailMapper;
	


	@Override
	public List<ProjectDto> getAll() {
		return projectRepository.findAll().stream().map(mapper::toDto).collect(Collectors.toList());

	}

	@Override
	public ProjectDto getById(Integer id) {
		return mapper.toDto(projectRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Project", "id", id)));
	}

	@Override
	public ProjectDto createProject(ProjectDto project) {
		projectRepository.save(mapper.toModel(project));
		return project;
	}

	@Override
	public ProjectDto updateProject(ProjectDto project, Integer id) {
		ProjectModel projectModel = projectRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Project", "id", id));
		
		projectModel.setLanguage(project.getLanguage());
		projectModel.setDescription(project.getDescription());
		projectModel.setOpen(project.isOpen());
//		projectModel.setDetail(detailMapper.toModel(project.getDetail()));
		
		
		return mapper.toDto(projectRepository.save(projectModel));
	}

	@Override
	public void deleteProjectById(Integer id) {
		ProjectModel project = projectRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Project", "id", id));
		
		projectRepository.delete(project);
	}

}
